const CHAVE_FAVORITOS = 'civic-favoritas';
const CHAVE_NOME = 'honda-nome-visitante';
const CHAVE_MENSAGENS = 'honda-mensagens';

const geracoes = [
  { id: 'g1', nome: 'Civic 1ª geração', anos: '1972–1979', decada: 1970, curiosidade: 'Estreou em 1972 e foi eleito Carro do Ano no Japão. Em 1973 chegou o motor CVCC, que reduzia as emissões sem catalisador.' },
  { id: 'g2', nome: 'Civic 2ª geração', anos: '1979–1983', decada: 1970, curiosidade: 'Ficou maior e com linhas mais retas, oferecendo mais espaço interno sem perder a economia.' },
  { id: 'g3', nome: 'Civic 3ª geração', anos: '1983–1987', decada: 1980, curiosidade: 'Teve teto alto e interior espaçoso, e dela nasceu o cupê esportivo CRX. A versão esportiva Si também surgiu nessa época.' },
  { id: 'g4', nome: 'Civic 4ª geração', anos: '1987–1991', decada: 1980, curiosidade: 'Ficou conhecida pela suspensão independente de duplo braço nas quatro rodas, que garantia ótimo comportamento nas curvas.' },
  { id: 'g5', nome: 'Civic 5ª geração', anos: '1991–1995', decada: 1990, curiosidade: 'Visual mais aerodinâmico e o motor VTEC chegando ao esportivo SiR, que virou objeto de desejo.' },
  { id: 'g6', nome: 'Civic 6ª geração', anos: '1995–2000', decada: 1990, curiosidade: 'Foi o primeiro Civic fabricado no Brasil, em Sumaré (SP), a partir de 1997. No mesmo ano nasceu o primeiro Civic Type R, no Japão.' },
  { id: 'g7', nome: 'Civic 7ª geração', anos: '2000–2005', decada: 2000, curiosidade: 'Ganhou interior mais amplo e, em 2002, a versão Civic Hybrid.' },
  { id: 'g8', nome: 'Civic 8ª geração', anos: '2005–2011', decada: 2000, curiosidade: 'Painel futurista com velocímetro digital em um nível superior, e estreia no Brasil em 2006.' },
  { id: 'g9', nome: 'Civic 9ª geração', anos: '2011–2015', decada: 2010, curiosidade: 'Linha focada em economia de combustível e em um acabamento mais refinado.' },
  { id: 'g10', nome: 'Civic 10ª geração', anos: '2015–2021', decada: 2010, curiosidade: 'Design mais baixo e largo, com a estreia do motor 1.5 turbo na linha.' },
  { id: 'g11', nome: 'Civic 11ª geração', anos: '2021–atual', decada: 2020, curiosidade: 'Visual mais sóbrio, painel com grade em favo de mel e foco em tecnologias de segurança.' }
];

const curiosidades = [
  'A Honda foi fundada em 1948 por Soichiro Honda, que antes fabricava anéis de pistão.',
  'O Civic estreou em 1972 e foi eleito Carro do Ano no Japão.',
  'O motor CVCC do Civic cumpriu as rígidas normas de emissões dos Estados Unidos sem usar catalisador.',
  'O Civic de sexta geração foi o primeiro fabricado no Brasil, em Sumaré (SP), a partir de 1997.',
  'O primeiro Civic Type R nasceu em 1997 e transformou o compacto em um esportivo de pista.',
  'O Civic Hybrid, versão com motor elétrico auxiliar, chegou em 2002.',
  'A Honda estreou na Fórmula 1 em 1964 e venceu pela primeira vez em 1965, no México.',
  'A moto Super Cub, lançada em 1958, ultrapassou a marca de 100 milhões de unidades produzidas.'
];

let ultimaCuriosidade = -1;

function lerFavoritos() {
  return JSON.parse(localStorage.getItem(CHAVE_FAVORITOS)) || [];
}

function alternarFavorito(id) {
  const favoritos = lerFavoritos();
  const novos = favoritos.includes(id)
    ? favoritos.filter((item) => item !== id)
    : [...favoritos, id];
  localStorage.setItem(CHAVE_FAVORITOS, JSON.stringify(novos));
}

function sortearCuriosidade() {
  const alvo = document.querySelector('#curiosidade');
  let indice;
  do {
    indice = Math.floor(Math.random() * curiosidades.length);
  } while (indice === ultimaCuriosidade);
  ultimaCuriosidade = indice;
  alvo.textContent = `${curiosidades[indice]}`;
}

function criarCartao(geracao, favorito) {
  return `<li class="cartao">
    <img src="img/${geracao.id}.svg" alt="Ilustração do ${geracao.nome}" width="320" height="150" loading="lazy">
    <h3>${geracao.nome}</h3>
    <span class="tag">${geracao.anos}</span>
    <p>${geracao.curiosidade}</p>
    <button type="button" class="botao botao-sec" data-id="${geracao.id}" aria-pressed="${favorito}">${favorito ? 'Remover dos favoritos' : 'Favoritar'}</button>
  </li>`;
}

function renderizarGeracoes() {
  const lista = document.querySelector('#lista-geracoes');
  const decada = document.querySelector('#decada').value;
  const soFavoritos = document.querySelector('#so-favoritos').checked;
  const favoritos = lerFavoritos();

  const filtrados = geracoes
    .filter((geracao) => decada === 'todas' || geracao.decada === Number(decada))
    .filter((geracao) => !soFavoritos || favoritos.includes(geracao.id));

  lista.innerHTML = filtrados.map((geracao) => criarCartao(geracao, favoritos.includes(geracao.id))).join('');
  document.querySelector('#status').textContent = filtrados.length === 0
    ? 'Nenhuma geração encontrada com esses filtros.'
    : `Exibindo ${filtrados.length} de ${geracoes.length} gerações. Favoritos: ${favoritos.length}.`;
}

function iniciarGeracoes() {
  renderizarGeracoes();
  document.querySelector('#decada').addEventListener('change', renderizarGeracoes);
  document.querySelector('#so-favoritos').addEventListener('change', renderizarGeracoes);
  document.querySelector('#lista-geracoes').addEventListener('click', (evento) => {
    const botao = evento.target.closest('button[data-id]');
    if (botao) {
      alternarFavorito(botao.dataset.id);
      renderizarGeracoes();
    }
  });
}

function validarCampo(campo, valido, mensagem) {
  document.querySelector(`#erro-${campo.id}`).textContent = valido ? '' : mensagem;
  campo.setAttribute('aria-invalid', !valido);
  return valido;
}

function enviarFormulario(evento) {
  evento.preventDefault();
  const nome = document.querySelector('#nome');
  const email = document.querySelector('#email');
  const mensagem = document.querySelector('#mensagem');

  const resultados = [
    validarCampo(nome, nome.value.trim().length >= 3, 'Digite seu nome com pelo menos 3 letras.'),
    validarCampo(email, email.checkValidity() && email.value !== '', 'Digite um e-mail válido.'),
    validarCampo(mensagem, mensagem.value.trim().length >= 10, 'Escreva uma mensagem com pelo menos 10 caracteres.')
  ];
  const retorno = document.querySelector('#retorno');

  if (resultados.includes(false)) {
    retorno.textContent = 'Corrija os campos indicados e tente novamente.';
    return;
  }

  const mensagens = JSON.parse(localStorage.getItem(CHAVE_MENSAGENS)) || [];
  mensagens.push({ nome: nome.value.trim(), email: email.value, texto: mensagem.value.trim() });
  localStorage.setItem(CHAVE_MENSAGENS, JSON.stringify(mensagens));
  localStorage.setItem(CHAVE_NOME, nome.value.trim());
  retorno.textContent = `Obrigado, ${nome.value.trim()}! Sua mensagem foi registrada neste navegador.`;
  evento.target.reset();
}

function iniciarContato() {
  const nomeSalvo = localStorage.getItem(CHAVE_NOME);
  if (nomeSalvo) {
    document.querySelector('#retorno').textContent = `Bem-vindo de volta, ${nomeSalvo}!`;
  }
  document.querySelector('#formulario').addEventListener('submit', enviarFormulario);
}

if (document.querySelector('#curiosidade')) {
  sortearCuriosidade();
  document.querySelector('#nova-curiosidade').addEventListener('click', sortearCuriosidade);
}
if (document.querySelector('#lista-geracoes')) {
  iniciarGeracoes();
}
if (document.querySelector('#formulario')) {
  iniciarContato();
}
