# Clássicos Honda

Site sobre carros clássicos da Honda (HTML, CSS e JS).

## Publicar no GitHub Pages
1. Crie um repositório e envie esta pasta `projeto`.
2. Em Settings > Pages, escolha a branch e a pasta onde está o `index.html`.
3. Se `projeto` for uma subpasta, use `/(root)` e acesse `usuario.github.io/repositorio/projeto/`.
